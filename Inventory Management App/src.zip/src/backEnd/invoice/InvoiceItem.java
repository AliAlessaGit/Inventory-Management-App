package backEnd.invoice;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class InvoiceItem implements Serializable {
    private long idNumber;   // معرف مطابق للعنصر في المخزون
    private String name;
    private double quantity;
    private double unitPrice;
    private double boxArea; // للبلاط فقط
    private boolean isTile;
    private String code;    // للبلاط فقط
    private String grade;   // النخب
    private LocalDateTime date; // <<<<<<<  أضف هذا الحقل

    private boolean externalItem;
    // --- كونستركتور للأدوات الصحية ---
    // داخل InvoiceItem
    public InvoiceItem(long idNumber, String name, double quantity, double unitPrice, double boxArea, boolean isTile, String code, String grade, LocalDateTime date) {
        // ... الإسنادات الموجودة مسبقًا
        this.idNumber = idNumber;
        this.name = name;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
        this.boxArea = boxArea;
        this.isTile = isTile;
        this.code = code;
        this.grade = grade;
        this.date = date; // <<<<<<< أضف هذا السطر
    }

    public InvoiceItem(
            String code,
            String name,
            String grade,
            double boxArea,
            double quantity,
            double unitPrice,
            LocalDateTime date) {

        this.idNumber = 0;
        this.code = code;
        this.name = name;
        this.grade = grade;
        this.boxArea = boxArea;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
        this.isTile = true;
        this.date = date;
        this.externalItem = true;
    }
    // هذا مثال لمنشئ الأدوات الصحية
    public InvoiceItem(long idNumber, String name, double quantity, double unitPrice, boolean isTile, String grade, LocalDateTime date) {
        // ... الإسنادات الموجودة مسبقًا
        this.idNumber = idNumber;
        this.name = name;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
        this.isTile = isTile;
        this.grade = grade;
        this.date = date; // <<<<<<< أضف هذا السطر
        this.boxArea = 0; // or whatever default
        this.code = ""; // or whatever default
    }
    // --- Constructor للعنصر الخارجي ---
    public InvoiceItem(String name, double quantity, double unitPrice, LocalDateTime date) {
        this.idNumber = 0;
        this.name = name;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
        this.boxArea = 0;
        this.isTile = false;
        this.code = "";
        this.grade = "";
        this.date = date;
        this.externalItem = true;
    }

    // =========================================================
// Constructor للبلاط الخارجي
// =========================================================

    public InvoiceItem(
            String code,
            String name,
            String grade,
            double quantity,
            double unitPrice,
            LocalDateTime date) {

        this.idNumber = 0;
        this.name = name;
        this.quantity = quantity;
        this.unitPrice = unitPrice;

        // البلاط الخارجي لا يعتمد على مساحة صندوق
        this.boxArea = 1.0;

        this.isTile = true;

        this.code = code;
        this.grade = grade;
        this.date = date;

        this.externalItem = true;
    }
    // <<<<<<< أضف هذا التابع (method)
    public String getFormattedDate() {
        if (this.date == null) {
            return ""; // أو تاريخ الفاتورة الافتراضي إذا لزم الأمر
        }
        return this.date.format(DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm"));
    }
    // ==== Getters ====
    public long getIdNumber() { return idNumber; }
    public String getName() { return name; }
    public double getQuantity() { return quantity; }
    public double getUnitPrice() { return unitPrice; }
    public double getBoxArea() { return boxArea; }
    public boolean isTile() { return isTile; }
    public boolean isExternalItem() {
        return externalItem;
    }
    public String getCode() { return isTile ? code : ""; }
    public String getGrade() { return grade; }

    public double getTotalPrice() {

        // البلاط الخارجي
        if (externalItem && isTile) {
            return quantity * boxArea * unitPrice;
        }

        // العنصر الخارجي العادي
        if (externalItem) {
            return quantity * unitPrice;
        }

        // البلاط من المخزون
        if (isTile) {
            return quantity * boxArea * unitPrice;
        }

        // الأدوات الصحية
        return quantity * unitPrice;
    }
}